#ifndef LISTA_H_INCLUDED
#define LISTA_H_INCLUDED
#include "Cadena.h"
#include "Producto.h"
#include "Cliente.h"

//para la lista de productos existentes
typedef struct nodo1
{
    Producto dato;
    int cantidad;
    nodo1 *sig;
} nodo2;
typedef nodo2 *Lista;

//para la lista de productos
void crearLista(Lista &l);
bool vaciarLista(Lista l);
void resto(Lista &l);
void insFront(Lista &l, Producto p, int cantidad);
void desplegarLista(Lista l);
bool perteneceLista(Lista l, Producto e);
Producto obtenerLista(Lista l, int e);
void borrarLista(Lista &l,int e);

#endif // LISTA_H_INCLUDED
